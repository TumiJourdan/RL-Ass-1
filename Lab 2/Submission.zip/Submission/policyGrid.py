import numpy as np


# up down left right
class GRID:
    def __init__(self) -> None:
        self.gridWorld = np.array([[20,17,16,15,14,13,12],
                                   [18,17,16,15,14,13,12],
                                   [0 ,0 ,0 ,0 ,0 ,0 ,11],
                                   [4 ,5 ,6 ,7 ,8 ,9,10],
                                   [3 ,4 ,5 ,6 ,7 ,8,9],
                                   [2 ,3 ,4 ,5 ,6 ,7,8],
                                   [1 ,2 ,3 ,4 ,5 ,6,7]
                                   ])
        
        
    
