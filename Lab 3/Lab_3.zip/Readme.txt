# 2332155 Tao Yuan
# 2424161 Shakeel Malagas
# 2180153 Tumi Jourdan

Run the value_itearation.py for outputs