The modes are :
PPO and A2C

A2C is a linear version of A3C which we covered in class.
PPO is the model that we investigated beyond the course content.