For baseline.py, CurriculumLearning.py and All_Improvements.py, env_GNN simply use python to run
Wandb will try to log you in, and will request an api key. 
Once the model is running, you can view results in console and wandb.

Each file is an improvement implemtation, which all culminate in the final file, "All_Improvements.py".

